﻿using Project_2016;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2016
{

    public partial class Form1 : Form
    {
        private int attachedPid = -1;

        private Form intro;

        private Form darkDexWindow;

        private SoundPlayer clickSound =
    new SoundPlayer(@"C:\Users\PC\Desktop\Project 2016\Project 2016\obj\Debug\sound effects\minecraft_click.wav");

        private SoundPlayer clicksound2 =
    new SoundPlayer(@"C:\Users\PC\Desktop\Project 2016\Project 2016\obj\Debug\sound effects\bow_shoot.wav");

        private SoundPlayer injectsound =
    new SoundPlayer(@"C:\Users\PC\Desktop\Project 2016\Project 2016\obj\Debug\sound effects\minecraft-rare-achievement.wav");

        private bool isAttached = false;

        private double rainbowOffset = 0;

        private float orbitAngle = 0;
        private Point uiCenter;

        private string scriptQueue = "";


        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out int lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr hObject);

        


        public Form1()
        {
            InitializeComponent();

            richTextBox2.ReadOnly = true;

            richTextBox1.MouseDown += richTextBox1_MouseDown;

        }

        // ctrl cool thing
        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left &&
                Control.ModifierKeys == Keys.Control)
            {
                int index = richTextBox1.GetCharIndexFromPosition(e.Location);

                MatchCollection matches = Regex.Matches(
                    richTextBox1.Text,
                    @"https?://[^\s]+"
                );

                foreach (Match match in matches)
                {
                    if (index >= match.Index &&
                        index <= match.Index + match.Length)
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = match.Value,
                            UseShellExecute = true
                        });

                        break;
                    }
                }
            }
        }



        //Clear Button
        private void button2_Click(object sender, EventArgs e)
        {
            clickSound.Play();
            richTextBox1.Clear();
            richTextBox2.Clear();
            richTextBox2.AppendText("[Executor] Text Cleared!\n");
        }
        //Memory Check Button
        private void button3_Click(object sender, EventArgs e)
        {

            {
                clickSound.Play();

                Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");

                if (processes.Length == 0)
                {
                    isAttached = false;
                    label1.Text = "● OFFLINE";
                    label1.ForeColor = Color.Red;
                    MessageBox.Show(
                        "Roblox is not running!\nPlease launch Roblox first.",
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    richTextBox2.AppendText("[Executor] ❌ Roblox not found.\n");
                    return;
                }

                richTextBox2.AppendText($"[Executor] Found Roblox (PID: {processes[0].Id})\n");


                if (isAttached)
                {
                    MessageBox.Show(
                        "Already attached!",
                        "Info",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }




                bool success = SimulateAttach(processes[0]);

                if (success)
                {
                    isAttached = true;
                    label1.Text = "● ONLINE";
                    label1.ForeColor = Color.LimeGreen;
                    injectsound.Play();

                    richTextBox2.AppendText("[Executor] ✅ Successfully Attached!\n");
                    MessageBox.Show(
                        "Attached Successfully!\n\nEnjoy :)",
                        "Success",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    richTextBox2.AppendText("[Executor] ❌ Attach Failed\n");
                    MessageBox.Show(
                        "Failed to attach.\nMake sure you run this program as Administrator.",
                        "Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }

            }
        }






        private bool IsRunningAsAdministrator()
        {
            using (var identity = System.Security.Principal.WindowsIdentity.GetCurrent())
            {
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
        }
        private bool IsRobloxRunning()
        {
            return Process.GetProcessesByName("RobloxPlayerBeta").Length > 0;
        }

        private bool SimulateAttach(Process robloxProcess)
        {
            try
            {
                // Real check for admin rights
                if (!IsRunningAsAdministrator())
                {
                    richTextBox2.AppendText("[Injector] Please run this program as Administrator!\n");
                    return false;
                }

                IntPtr handle = OpenProcess(0x1F0FFF, false, robloxProcess.Id);
                if (handle == IntPtr.Zero)
                {
                    richTextBox2.AppendText("[Injector] Failed to open process handle.\n");
                    return false;
                }

                CloseHandle(handle);

                // Simulate some work
                System.Threading.Thread.Sleep(200);
                richTextBox2.AppendText("[Injector] Bomboclat ✓\n");

                return true;
            }
            catch (Exception ex)
            {
                richTextBox2.AppendText($"[Injector] Error: {ex.Message}\n");
                return false;



            }
        }
       




        //Execute Button
        private void button1_Click(object sender, EventArgs e)
        {

            if (!IsRobloxRunning())
            {
                isAttached = false;

                label1.Text = "● OFFLINE";
                label1.ForeColor = Color.Red;

                MessageBox.Show(
                    "Attach First!",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }






            clickSound.Play();

            if (!isAttached)
            {
                MessageBox.Show("Attach first Bro 💔", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox2.AppendText("[Executor] Attach First (Click On Memory Check Button)\n");
                return;
            }

            Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
            if (processes.Length == 0)
            {
                label1.Text = "● OFFLINE";
                label1.ForeColor = Color.Red;
                MessageBox.Show("Attach first!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox2.AppendText("[Executor] Attach First (Click On Memory Check Button)\n");
                return;
            }

            string script = richTextBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(script))
            {
                MessageBox.Show("No script entered!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox2.AppendText("[Executor] Failed To Execute The Script..\n");
                return;
            }

            try
            {
                bool success = ExecuteToRoblox(script);

                if (success)
                {
                    string[] lines = script.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                    string preview = string.Join(Environment.NewLine, lines.Take(5));
                    if (lines.Length > 5)
                        preview += Environment.NewLine + "// ... (Script is longer)";

                    MessageBox.Show("Executed Script:\n\n" + preview, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    richTextBox2.AppendText("[Executor] The Script Executed Successfully!!\n");
                }
                else
                {
                    MessageBox.Show("Failed to inject script into Roblox.", "Execution Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    richTextBox2.AppendText("[Executor] Failed To Execute The Script..\n");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Execution Error:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                richTextBox2.AppendText($"[Executor] Error: {ex.Message}\n");
            }
        }



        private bool ExecuteToRoblox(string script)
        {
            if (!isAttached)
                return false;

            try
            {
                Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
                if (processes.Length == 0) return false;

                IntPtr handle = OpenProcess(0x1F0FFF, false, processes[0].Id);
                if (handle == IntPtr.Zero) return false;

                byte[] payload = Encoding.UTF8.GetBytes(script + "\0");

                IntPtr allocMem = VirtualAllocEx(handle, IntPtr.Zero, (uint)payload.Length, 0x3000, 0x40);
                if (allocMem == IntPtr.Zero)
                {
                    CloseHandle(handle);
                    return false;
                }

                WriteProcessMemory(handle, allocMem, payload, (uint)payload.Length, out _);

                richTextBox2.AppendText("[Executor] Script written to Roblox memory\n");
                CloseHandle(handle);
                return true;
            }
            catch
            {
                return false;
            }
        }









        private void button4_Click(object sender, EventArgs e)
        {
            clicksound2.Play();
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Files (*.rtf)|*.rtf|All Files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                // Load RTF or normal text
                if (Path.GetExtension(filePath) == ".rtf")
                {
                    richTextBox1.LoadFile(filePath);
                }
                else
                {
                    richTextBox1.Text = File.ReadAllText(filePath);
                }
            }
        }
        //just a form1load
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 180;
            timer1.Tick += timer1_Tick;
            timer1.Start();
            

        }

        //rainbow text color for the output :3
        private Color GetRainbowColor(double t)
        {
            int r = (int)(Math.Sin(t) * 127 + 128);
            int g = (int)(Math.Sin(t + 2) * 127 + 128);
            int b = (int)(Math.Sin(t + 4) * 127 + 128);

            return Color.FromArgb(r, g, b);
        }

        private void RainbowText()
        {
            if (richTextBox2.TextLength == 0)
                return;

            int start = richTextBox2.GetFirstCharIndexFromLine(
                richTextBox2.GetLineFromCharIndex(richTextBox2.GetCharIndexFromPosition(new Point(1, 1)))
            );

            int end = richTextBox2.GetCharIndexFromPosition(
                new Point(1, richTextBox2.ClientSize.Height)
            );

            if (end <= 0)
                end = richTextBox2.TextLength;

            int savePos = richTextBox2.SelectionStart;
            int saveLength = richTextBox2.SelectionLength;

            richTextBox2.SuspendLayout();

            for (int i = start; i < end; i++)
            {
                richTextBox2.Select(i, 1);
                richTextBox2.SelectionColor =
                    GetRainbowColor(i * 0.10 + rainbowOffset);
            }

            richTextBox2.SelectionStart = savePos;
            richTextBox2.SelectionLength = saveLength;

            richTextBox2.ResumeLayout();
        }




        //R6 Button
        private void button5_Click(object sender, EventArgs e)
        {
            clickSound.Play();
        }

        //Re Button
        private void button6_Click(object sender, EventArgs e)
        {
            clickSound.Play();

        }
        //Dex Button


        private async void button7_Click(object sender, EventArgs e)
        {

            if (!IsRobloxRunning())
            {
                isAttached = false;

                label1.Text = "● OFFLINE";
                label1.ForeColor = Color.Red;

                MessageBox.Show(
                    "Attach First!",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }






            clickSound.Play();

            if (!isAttached)
            {
                MessageBox.Show("Attach first Bro 💔", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox2.AppendText("[Executor] Attach First To Run Dex\n");
                return;
            }



            Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
            if (processes.Length == 0)
            {
                label1.Text = "● OFFLINE";
                label1.ForeColor = Color.Red;
                MessageBox.Show("Attach first!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox2.AppendText("[Executor] Attach First To Load Dex\n");
                return;
            }










            if (intro != null && !intro.IsDisposed)
            {
                MessageBox.Show("Already Running..", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Already open?
            if (darkDexWindow != null && !darkDexWindow.IsDisposed)
                {
                MessageBox.Show("Already Running..", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }



            // ===== INTRO WINDOW =====
            intro = new Form();
            intro.FormBorderStyle = FormBorderStyle.None;
            intro.StartPosition = FormStartPosition.CenterScreen;
            intro.Size = new Size(320, 160);
            intro.BackColor = Color.FromArgb(20, 20, 20);
            intro.Opacity = 0;

            Label text = new Label();
            text.Text = "Dark Dex\nLoading...";
            text.ForeColor = Color.White;
            text.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            text.TextAlign = ContentAlignment.MiddleCenter;
            text.Dock = DockStyle.Fill;

            intro.Controls.Add(text);
            intro.Show();

            intro.TopMost = true;

            // ===== FADE IN =====
            for (double i = 0; i <= 1; i += 0.08)
            {
                intro.Opacity = i;
                await Task.Delay(20);
            }


            await Task.Delay(3000);

            // ===== FADE OUT =====
            for (double i = 1; i >= 0; i -= 0.08)
            {
                intro.Opacity = i;
                await Task.Delay(20);
            }

            intro.Close();








            darkDexWindow = new Form();
            darkDexWindow.Text = "Dark Dex";
            darkDexWindow.Size = new Size(400, 600);
            darkDexWindow.BackColor = Color.FromArgb(30, 30, 30);
            darkDexWindow.MaximizeBox = false;

            TreeView explorer = new TreeView();
            explorer.Dock = DockStyle.Fill;
            explorer.BackColor = Color.FromArgb(40, 40, 40);
            explorer.ForeColor = Color.White;
            explorer.BorderStyle = BorderStyle.None;
            darkDexWindow.TopMost = true;

            TreeNode game = new TreeNode("RobloxPlayerBeta.exe");

            TreeNode workspace = new TreeNode("Workspace");
            workspace.Nodes.Add("Baseplate");
            workspace.Nodes.Add("SpawnLocation");
            workspace.Nodes.Add("Map");
            workspace.Nodes.Add("Tree");
            workspace.Nodes.Add("House");
            workspace.Nodes.Add("NPC");

            TreeNode players = new TreeNode("Players");
            players.Nodes.Add("Player1");
            players.Nodes.Add("Player2");

            TreeNode lighting = new TreeNode("Lighting");
            lighting.Nodes.Add("Sky");
            lighting.Nodes.Add("Atmosphere");
            lighting.Nodes.Add("BloomEffect");
            lighting.Nodes.Add("ColorCorrection");

            TreeNode replicatedStorage = new TreeNode("ReplicatedStorage");
            replicatedStorage.Nodes.Add("RemoteEvent");
            replicatedStorage.Nodes.Add("RemoteFunction");
            replicatedStorage.Nodes.Add("Assets");

            TreeNode starterGui = new TreeNode("StarterGui");
            starterGui.Nodes.Add("MainMenu");
            starterGui.Nodes.Add("InventoryGui");
            starterGui.Nodes.Add("SettingsGui");

            TreeNode starterPack = new TreeNode("StarterPack");
            starterPack.Nodes.Add("Sword");
            starterPack.Nodes.Add("Flashlight");

            TreeNode starterPlayer = new TreeNode("StarterPlayer");
            starterPlayer.Nodes.Add("StarterCharacterScripts");
            starterPlayer.Nodes.Add("StarterPlayerScripts");

            TreeNode soundService = new TreeNode("SoundService");
            soundService.Nodes.Add("BackgroundMusic");
            soundService.Nodes.Add("AmbientSound");

            TreeNode teams = new TreeNode("Teams");
            teams.Nodes.Add("Red");
            teams.Nodes.Add("Blue");
            teams.Nodes.Add("Neutral");

            TreeNode serverScriptService = new TreeNode("ServerScriptService");
            serverScriptService.Nodes.Add("DataManager");
            serverScriptService.Nodes.Add("RoundSystem");

            TreeNode serverStorage = new TreeNode("ServerStorage");
            serverStorage.Nodes.Add("Weapons");
            serverStorage.Nodes.Add("Maps");

            game.Nodes.Add(workspace);
            game.Nodes.Add(players);
            game.Nodes.Add(lighting);
            game.Nodes.Add(replicatedStorage);
            game.Nodes.Add(starterGui);
            game.Nodes.Add(starterPack);
            game.Nodes.Add(starterPlayer);
            game.Nodes.Add(soundService);
            game.Nodes.Add(teams);
            game.Nodes.Add(serverScriptService);
            game.Nodes.Add(serverStorage);

            explorer.Nodes.Add(game);

            game.Expand();
            workspace.Expand();


            darkDexWindow.Controls.Add(explorer);
            darkDexWindow.Show();


        }
        //Online / Offline Text
        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        //OutPut
        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            richTextBox2.TabStop = false;
        }
        //Editor
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

            //colorfull editor code :3
            int selStart = richTextBox1.SelectionStart;
            int selLength = richTextBox1.SelectionLength;

            richTextBox1.SuspendLayout();

            // Normal text
            richTextBox1.SelectAll();
            richTextBox1.SelectionColor = Color.Black;

            // Luau keywords
            string[] keywords =
            {
        "local","function","end","if","then","else","elseif",
        "for","while","do","repeat","until","return",
        "break","continue","and","or","not","nil","true","false"
    };

            foreach (string keyword in keywords)
            {
                foreach (Match m in Regex.Matches(
                    richTextBox1.Text,
                    $@"\b{Regex.Escape(keyword)}\b"))
                {
                    richTextBox1.Select(m.Index, m.Length);
                    richTextBox1.SelectionColor = Color.Red;
                }
            }

            // Strings
            foreach (Match m in Regex.Matches(
                richTextBox1.Text,
                "\".*?\"|'.*?'"))
            {
                richTextBox1.Select(m.Index, m.Length);
                richTextBox1.SelectionColor = Color.LimeGreen;
            }

            // Comments
            foreach (Match m in Regex.Matches(
                richTextBox1.Text,
                @"--.*"))
            {
                richTextBox1.Select(m.Index, m.Length);
                richTextBox1.SelectionColor = Color.Gray;
            }

            // Numbers
            foreach (Match m in Regex.Matches(
                richTextBox1.Text,
                @"\b\d+(\.\d+)?\b"))
            {
                richTextBox1.Select(m.Index, m.Length);
                richTextBox1.SelectionColor = Color.Orange;
            }

            // Common Roblox globals
            string[] globals =
            {
        "game","workspace","script",
        "Instance","Vector3","CFrame",
        "Color3","Enum"
    };

            foreach (string g in globals)
            {
                foreach (Match m in Regex.Matches(
                    richTextBox1.Text,
                    $@"\b{Regex.Escape(g)}\b"))
                {
                    richTextBox1.Select(m.Index, m.Length);
                    richTextBox1.SelectionColor = Color.Gold;
                }
            }

            richTextBox1.SelectionStart = selStart;
            richTextBox1.SelectionLength = selLength;
            richTextBox1.SelectionColor = Color.Black;

            richTextBox1.ResumeLayout();
            
        }

        //Editor For The Rainbow Text :3
        private void timer1_Tick(object sender, EventArgs e)
        {
            rainbowOffset += 0.2;
            RainbowText();
        }
    }
}




//login shit


namespace Project_2016
{
    public class LoginForm : Form
    {
        TextBox txtUsername;
        TextBox txtPassword;
        Button btnLogin;

        public LoginForm()
        {
            Text = "Login";
            Size = new Size(350, 220);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label lblUser = new Label()
            {
                Text = "Username",
                Left = 30,
                Top = 30,
                Width = 80
            };

            txtUsername = new TextBox()
            {
                Left = 120,
                Top = 25,
                Width = 150
            };

            Label lblPass = new Label()
            {
                Text = "Password",
                Left = 30,
                Top = 80,
                Width = 80
            };

            txtPassword = new TextBox()
            {
                Left = 120,
                Top = 75,
                Width = 150,
                UseSystemPasswordChar = true
            };

            btnLogin = new Button()
            {
                Text = "Login",
                Left = 120,
                Top = 130,
                Width = 100
            };

            btnLogin.Click += BtnLogin_Click;

            Controls.Add(lblUser);
            Controls.Add(txtUsername);
            Controls.Add(lblPass);
            Controls.Add(txtPassword);
            Controls.Add(btnLogin);
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "MrBeastHax11" &&
                txtPassword.Text == "Pro2016")
            {
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show(
                    "Wrong username or password!",
                    "Login Failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}